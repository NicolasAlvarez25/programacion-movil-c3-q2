<template>
    <ion-app>
      <!-- Encabezado Principal -->
      <ion-header>
        <ion-toolbar color="primary">
          <ion-title>Ejemplo de 10 Componentes</ion-title>
        </ion-toolbar>
      </ion-header>
  
      <ion-content class="ion-padding">
  
        <!-- Componente de Alerta -->
        <ion-card>
          <ion-card-header>
            <ion-card-title>Mostrar Alerta</ion-card-title>
          </ion-card-header>
          <ion-card-content>
            <ion-button expand="full" color="warning" @click="mostrarAlerta">
              Alerta
            </ion-button>
          </ion-card-content>
        </ion-card>
  
        <!-- Componente de Checkbox -->
        <ion-card>
          <ion-card-header>
            <ion-card-title>Seleccionar Preferencias</ion-card-title>
          </ion-card-header>
          <ion-card-content>
            <ion-item>
              <ion-label>Opción 1</ion-label>
              <ion-checkbox slot="end" v-model="opcion1"></ion-checkbox>
            </ion-item>
            <ion-item>
              <ion-label>Opción 2</ion-label>
              <ion-checkbox slot="end" v-model="opcion2"></ion-checkbox>
            </ion-item>
          </ion-card-content>
        </ion-card>
  
        <!-- Componente de Fecha (Date Picker) -->
        <ion-card>
          <ion-card-header>
            <ion-card-title>Seleccionar Fecha</ion-card-title>
          </ion-card-header>
          <ion-card-content>
            <ion-datetime display-format="DD/MM/YYYY" v-model="fechaSeleccionada"></ion-datetime>
          </ion-card-content>
        </ion-card>
  
        <!-- Componente de Radio Button -->
        <ion-card>
          <ion-card-header>
            <ion-card-title>Seleccionar Género</ion-card-title>
          </ion-card-header>
          <ion-card-content>
            <ion-radio-group v-model="genero">
              <ion-item>
                <ion-label>Masculino</ion-label>
                <ion-radio slot="start" value="Masculino"></ion-radio>
              </ion-item>
              <ion-item>
                <ion-label>Femenino</ion-label>
                <ion-radio slot="start" value="Femenino"></ion-radio>
              </ion-item>
            </ion-radio-group>
          </ion-card-content>
        </ion-card>
  
        <!-- Componente de Rango (Slider) -->
        <ion-card>
          <ion-card-header>
            <ion-card-title>Ajustar Volumen</ion-card-title>
          </ion-card-header>
          <ion-card-content>
            <ion-range v-model="volumen" min="0" max="100" pin></ion-range>
          </ion-card-content>
        </ion-card>
  
        <!-- Componente de Selección (Select) -->
        <ion-card>
          <ion-card-header>
            <ion-card-title>Seleccionar País</ion-card-title>
          </ion-card-header>
          <ion-card-content>
            <ion-select v-model="paisSeleccionado" placeholder="Seleccione uno">
              <ion-select-option value="Colombia">Colombia</ion-select-option>
              <ion-select-option value="México">México</ion-select-option>
              <ion-select-option value="Argentina">Argentina</ion-select-option>
            </ion-select>
          </ion-card-content>
        </ion-card>
  
        <!-- Componente de Segmento -->
        <ion-card>
          <ion-card-header>
            <ion-card-title>Ver Categorías</ion-card-title>
          </ion-card-header>
          <ion-card-content>
            <ion-segment v-model="categoriaSeleccionada">
              <ion-segment-button value="Noticias">Noticias</ion-segment-button>
              <ion-segment-button value="Deportes">Deportes</ion-segment-button>
              <ion-segment-button value="Entretenimiento">Entretenimiento</ion-segment-button>
            </ion-segment>
          </ion-card-content>
        </ion-card>
  
        <!-- Componente de Spinner (Cargando) -->
        <ion-card>
          <ion-card-header>
            <ion-card-title>Cargando</ion-card-title>
          </ion-card-header>
          <ion-card-content>
            <ion-spinner name="crescent"></ion-spinner>
          </ion-card-content>
        </ion-card>
  
        <!-- Componente de Toggle (Activar Modo Oscuro) -->
        <ion-card>
          <ion-card-header>
            <ion-card-title>Modo Oscuro</ion-card-title>
          </ion-card-header>
          <ion-card-content>
            <ion-item>
              <ion-label>Activar</ion-label>
              <ion-toggle v-model="modoOscuro"></ion-toggle>
            </ion-item>
          </ion-card-content>
        </ion-card>
  
        <!-- Componente de Toast (Notificación) -->
        <ion-card>
          <ion-card-header>
            <ion-card-title>Mostrar Notificación</ion-card-title>
          </ion-card-header>
          <ion-card-content>
            <ion-button expand="full" color="danger" @click="mostrarNotificacion">
              Notificar
            </ion-button>
          </ion-card-content>
        </ion-card>
  
      </ion-content>
    </ion-app>
  </template>
  
  <script setup>
  import { ref } from 'vue';
  import { alertController, toastController } from '@ionic/vue';
  
  // Estado de los componentes
  const opcion1 = ref(false);
  const opcion2 = ref(false);
  const fechaSeleccionada = ref('');
  const genero = ref('');
  const volumen = ref(50);
  const paisSeleccionado = ref('');
  const categoriaSeleccionada = ref('Noticias');
  const modoOscuro = ref(false);
  
  // Función para mostrar una alerta
  const mostrarAlerta = async () => {
    const alert = await alertController.create({
      header: 'Alerta',
      message: 'Este es un mensaje de alerta',
      buttons: ['OK']
    });
    await alert.present();
  };
  
  // Función para mostrar una notificación (Toast)
  const mostrarNotificacion = async () => {
    const toast = await toastController.create({
      message: 'Notificación enviada con éxito',
      duration: 2000,
      position: 'top'
    });
    await toast.present();
  };
  </script>
  
  <style scoped>
  /* Estilos personalizados */
  .ion-padding {
    padding: 16px;
  }
  </style>
  