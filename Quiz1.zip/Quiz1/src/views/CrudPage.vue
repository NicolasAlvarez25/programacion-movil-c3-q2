<template>
    <div id="app">
      <h1>Gestión de usuarios</h1>
  
      <div class="user-form-container" v-if="showForm">
        <h3>{{ isEdit ? "Editar usuario" : "Agregar usuario" }}</h3>
        <form @submit.prevent="handleSaveUser" class="user-form">
          <label>
            Nombre:
            <input type="text" v-model="userForm.name" placeholder="Escribe tu nombre" required />
          </label>
          <label>
            Correo electrónico:
            <input type="email" v-model="userForm.email" placeholder="Escribe tu correo electrónico" required />
          </label>
          <div class="form-buttons">
            <button type="submit" class="save-button">{{ isEdit ? "Actualizar" : "Agregar" }}</button>
            <button type="button" @click="clearForm" class="cancel-button">Cancelar</button>
          </div>
        </form>
      </div>
  
      <div v-else class="add-user-button-container">
        <button @click="showForm = true" class="add-user-button">Agregar nuevo usuario</button>
      </div>
  
      <div class="user-list-container">
        <h3>Lista de usuarios</h3>
        <ul class="user-list">
          <li v-for="user in users" :key="user.id" class="user-item">
            <img :src="user.imageUrl || defaultImage" alt="Profile" class="user-image" />
            <span class="user-info">{{ user.name }} - {{ user.email }}</span>
            <div class="user-item-buttons">
              <button @click="handleEditUser(user)" class="edit-button">✏️</button>
              <button @click="handleDeleteUser(user.id)" class="delete-button">🗑️</button>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        users: [
          { id: 1, name: "Nicolás Álvarez", email: "nicolas@gmail.com", imageUrl: "https://via.placeholder.com/50" },
          { id: 2, name: "Edgar Álvarez", email: "edgar@gmail.com", imageUrl: "https://via.placeholder.com/50" },
        ],
        showForm: false,
        isEdit: false,
        userForm: {
          id: null,
          name: "",
          email: "",
          imageUrl: "",
        },
        defaultImage: "https://via.placeholder.com/50",
      };
    },
    methods: {
      handleSaveUser() {
        if (this.isEdit) {
          this.users = this.users.map((u) => (u.id === this.userForm.id ? { ...this.userForm } : u));
        } else {
          this.userForm.id = Date.now();
          this.userForm.imageUrl = this.userForm.imageUrl || this.defaultImage;
          this.users.push({ ...this.userForm });
        }
        this.clearForm();
      },
      handleEditUser(user) {
        this.userForm = { ...user };
        this.isEdit = true;
        this.showForm = true;
      },
      handleDeleteUser(userId) {
        this.users = this.users.filter((user) => user.id !== userId);
      },
      clearForm() {
        this.userForm = { id: null, name: "", email: "", imageUrl: "" };
        this.isEdit = false;
        this.showForm = false;
      },
    },
  };
  </script>
  
  <style scoped>
  #app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    text-align: center;
    margin-top: 40px;
    color: #333;
  }
  
  h1 {
    color: #4CAF50;
    margin-bottom: 20px;
  }
  
  .user-form-container {
    background-color: #f7f7f7;
    border-radius: 8px;
    padding: 20px;
    max-width: 400px;
    margin: 20px auto;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  }
  
  .user-form label {
    display: flex;
    flex-direction: column;
    margin-bottom: 10px;
    font-weight: bold;
    color: #555;
  }
  
  .user-form input {
    padding: 8px;
    margin-top: 5px;
    font-size: 16px;
    border-radius: 4px;
    border: 1px solid #ccc;
  }
  
  .form-buttons {
    display: flex;
    justify-content: space-between;
    margin-top: 15px;
  }
  
  .save-button {
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  
  .cancel-button {
    background-color: #f44336;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  
  .add-user-button-container {
    margin: 20px;
  }
  
  .add-user-button {
    background-color: #2196F3;
    color: white;
    padding: 10px 20px;
    font-size: 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  
  .user-list-container {
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
  }
  
  .user-list {
    list-style-type: none;
    padding: 0;
  }
  
  .user-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    background-color: #f1f1f1;
    margin-bottom: 10px;
    border-radius: 4px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  
  .user-image {
    border-radius: 50%;
    width: 50px;
    height: 50px;
    margin-right: 10px;
  }
  
  .user-info {
    font-size: 16px;
    color: #333;
    flex: 1;
    text-align: left;
  }
  
  .user-item-buttons button {
    margin-left: 5px;
    padding: 8px 12px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  
  .edit-button {
    background-color: #FFC107;
    color: white;
  }
  
  .delete-button {
    background-color: #f44336;
    color: white;
  }
  </style>
  